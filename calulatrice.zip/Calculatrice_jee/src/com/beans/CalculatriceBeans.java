package com.beans;

import javax.servlet.http.HttpServletRequest;

public class CalculatriceBeans {
	private double number1;
	private double number2;
	private String operator;
	private double resultat;
	
	public double getNumber1() {
		return number1;
	}

	public void setNumber1(double number1) {
		this.number1 = number1;
	}

	public double getNumber2() {
		return number2;
	}

	public void setNumber2(double number2) {
		this.number2 = number2;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public double getResultat() {
		return resultat;
	}

	public void setResultat(double resultat) {
		this.resultat = resultat;
	}

	private double calculate(double number1, double number2, String operator) {	
		switch (operator) {
		case "+":
			resultat = number1 + number2;
			break;
		case "-":
			resultat = number1 - number2;
			break;
		case "*":
			resultat = number1 * number2;
			break;
		case "/":
			resultat = number1 / number2;
			break;
		}
		return resultat;
	}
	
	private void dataPreparing(HttpServletRequest request) {
		request.setAttribute("resultat", this.calculate(this.getNumber1(), this.getNumber2(), this.getOperator()));
		request.setAttribute("calculatrice", this);
	}
	
	public void dataProcessing(HttpServletRequest request) {
		try {
			this.setNumber1(Double.valueOf((String)request.getParameter("number1")));
			this.setNumber2(Double.valueOf((String)request.getParameter("number2")));
			this.setOperator((String)request.getParameter("operator"));
			this.dataPreparing(request);
		}
		catch (Exception e) {
			request.setAttribute("error", " ATTENTION : Veuillez remplir les deux champs pr�vus !");
		}
	}
}
