package com.beans;

public class CalculatriceBeans {
	private int number1;
	private int number2;
	private String operator;
	private int resultat;
	
	public int getNumber1() {
		return number1;
	}
	
	public void setNumber1(int number1) {
		this.number1 = number1;
	}
	
	public int getNumber2() {
		return number2;
	}
	
	public void setNumber2(int number2) {
		this.number2 = number2;
	}
	
	public String getOperator() {
		return operator;
	}
	
	public void setOperator(String operator) {
		this.operator = operator;
	}
	
	public int getResultat() {
		return resultat;
	}
	
	public void setResultat(int resultat) {
		this.resultat = resultat;
	}
	
	public int calculate(int number1, int number2, String operator) {
			
		switch (operator) {
		case "+":
			resultat = number1 + number2;
			break;
		case "-":
			resultat = number1 - number2;
			break;
		case "*":
			resultat = number1 * number2;
			break;
		case "/":
			resultat = number1 / number2;
			break;
		}
		return resultat;
	}
}
